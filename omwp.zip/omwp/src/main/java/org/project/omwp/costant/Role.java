package org.project.omwp.costant;

public enum Role {
    ADMIN, MEMBER;
}
